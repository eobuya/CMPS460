//
//  GameScene.swift
//  CrazyJumpGame
//
//  Created by user150240 on 4/9/19.
//  Copyright © 2019 edwin. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var landShark : SKSpriteNode?
    var gameTimer : Timer?
    var dynamiteTimer : Timer?
    var ground : SKSpriteNode?
    var ceiling : SKSpriteNode?
    var scoreLabel : SKLabelNode?
    var finalScoreLabel : SKLabelNode?
    var yourScoreLabel : SKLabelNode?

    let landSharkCategory : UInt32 = 0x1 << 1
    let coinCategory : UInt32 = 0x1 << 2
    let dynamiteCategory : UInt32 = 0x1 << 3
    let groundAndCeilingCategory : UInt32 = 0x1 << 4
    
    var score = 0
    
    override func didMove(to view: SKView) {
        
        landShark = childNode(withName: "landShark") as? SKSpriteNode
        generateCoin()
        
        //Collision
        physicsWorld.contactDelegate = self
        
        landShark = childNode(withName: "landShark") as? SKSpriteNode
        landShark?.physicsBody?.categoryBitMask = landSharkCategory
        landShark?.physicsBody?.contactTestBitMask = coinCategory | dynamiteCategory
        landShark?.physicsBody?.collisionBitMask = groundAndCeilingCategory
        var landSharkRun : [SKTexture] = []
        for number in 1...8 {
            landSharkRun.append(SKTexture(imageNamed: "a\(number)"))
        }
        
        landShark?.run(SKAction.repeatForever(SKAction.animate(with: landSharkRun, timePerFrame: 0.09)))
      
        /*
        ground = childNode(withName: "ground") as? SKSpriteNode
        ground?.physicsBody?.categoryBitMask = groundAndCeilingCategory
        ground?.physicsBody?.collisionBitMask = landSharkCategory
        
        ceiling = childNode(withName: "ceiling") as? SKSpriteNode
        ceiling?.physicsBody?.categoryBitMask = groundAndCeilingCategory
        ceiling?.physicsBody?.collisionBitMask = landSharkCategory
        */
        
        scoreLabel = childNode(withName: "scoreLabel") as? SKLabelNode
        
        startTimers()
        generateGround()
    }
    
    func generateGround() {
        let sizingGround = SKSpriteNode(imageNamed: "ground")
        let numberOfGround = Int(size.width / sizingGround.size.width) + 1
        for number in 0...numberOfGround {
            let ground = SKSpriteNode(imageNamed: "ground")
            ground.physicsBody = SKPhysicsBody(rectangleOf: ground.size)
            ground.physicsBody?.categoryBitMask = groundAndCeilingCategory
            ground.physicsBody?.collisionBitMask = landSharkCategory
            ground.physicsBody?.affectedByGravity = false
            ground.physicsBody?.isDynamic = false
            addChild(ground)
            
            let groundX = -size.width / 2 + ground.size.width / 2 + ground.size.width * CGFloat(number)
            ground.position = CGPoint(x: groundX, y: -size.height / 2 + ground.size.height / 2 - 18)
            let speed = 100.0
            let firstMoveLeft = SKAction.moveBy(x: -ground.size.width - ground.size.width * CGFloat(number), y: 0, duration: TimeInterval(ground.size.width + ground.size.width * CGFloat(number)) / speed)
            
            let resetGround = SKAction.moveBy(x: size.width + ground.size.width, y: 0, duration: 0)
            let groundFullMove = SKAction.moveBy(x: -size.width - ground.size.width, y: 0, duration: TimeInterval(size.width + ground.size.width) / speed)
            let groundMovingForever = SKAction.repeatForever(SKAction.sequence([groundFullMove, resetGround]))
            
            ground.run(SKAction.sequence([firstMoveLeft,resetGround,groundMovingForever]))
            
            
        }
    }
    
    func startTimers() {
        //Coin Timer
        gameTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: {(Timer) in self.generateCoin()
        })
        
        //Dynamite Time
        dynamiteTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true, block: {(Timer) in self.generateExplosion()
        })
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if scene?.isPaused == false {
            landShark?.physicsBody?.applyForce(CGVector(dx: 0, dy: 25000))
        }
        
        let touch = touches.first
        if let location = touch?.location(in: self) {
            let theNodes = nodes(at: location)
            
            for node in theNodes {
                if node.name == "play" {
                    score = 0 //Restart game
                    node.removeFromParent()
                    finalScoreLabel?.removeFromParent()
                    yourScoreLabel?.removeFromParent()
                    scene?.isPaused = false
                    scoreLabel?.text = "Score: \(score)"
                    startTimers()
                }
            }
        }
    }

    func generateCoin() {
        let coin = SKSpriteNode(imageNamed: "coin")
        coin.physicsBody = SKPhysicsBody(rectangleOf: coin.size)
        coin.physicsBody?.affectedByGravity = false
        coin.physicsBody?.categoryBitMask = coinCategory
        coin.physicsBody?.contactTestBitMask = landSharkCategory
        coin.physicsBody?.collisionBitMask = 0
        addChild(coin)
        
        let sizingGround = SKSpriteNode(imageNamed: "ground")

        //Setting the height structure
        let maximumY = size.height / 2 - coin.size.height / 2
        let minimumY = -size.height / 2 + coin.size.height / 2 + sizingGround.size.height
        let range = maximumY - minimumY
        let coinY = maximumY - CGFloat(arc4random_uniform(UInt32(range)))
        
        //Setup Variables to handle the direction
        coin.position = CGPoint(x: size.width / 2 + coin.size.width / 2, y: coinY)
        
        //Setup the direction of the coin and speed
        let moveLeft = SKAction.moveBy(x: -size.width - coin.size.width, y: 0, duration: 5)
        coin.run(SKAction.sequence([moveLeft, SKAction.removeFromParent()]))
    }
    
    func generateExplosion () {
        let dynamite = SKSpriteNode(imageNamed: "dynamite")
        dynamite.physicsBody = SKPhysicsBody(rectangleOf: dynamite.size)
        dynamite.physicsBody?.affectedByGravity = false
        dynamite.physicsBody?.categoryBitMask = dynamiteCategory
        dynamite.physicsBody?.contactTestBitMask = landSharkCategory
        dynamite.physicsBody?.collisionBitMask = 0
        addChild(dynamite)
        
        let sizingGround = SKSpriteNode(imageNamed: "ground")
        
        //Setting the height structure
        let maximumY = size.height / 2 - dynamite.size.height / 2
        let minimumY = -size.height / 2 + dynamite.size.height / 2 + sizingGround.size.height
        let range = maximumY - minimumY
        let dynamiteY = maximumY - CGFloat(arc4random_uniform(UInt32(range)))
        
        //Setup Variables to handle the direction
        dynamite.position = CGPoint(x: size.width / 2 + dynamite.size.width / 2, y: dynamiteY)
        
        //Setup the direction of the coin and speed
        let moveLeft = SKAction.moveBy(x: -size.width - dynamite.size.width, y: 0, duration: 5)
        dynamite.run(SKAction.sequence([moveLeft, SKAction.removeFromParent()]))
    }
    
    func didBegin(_ contact: SKPhysicsContact){
       score += 1
       scoreLabel?.text = "Score: \(score)"
    
       //Rules
       if contact.bodyA.categoryBitMask == coinCategory {
           contact.bodyA.node?.removeFromParent()
           score += 1
           scoreLabel?.text = "Score: \(score)"
       }
        
       if contact.bodyB.categoryBitMask == coinCategory {
           contact.bodyB.node?.removeFromParent()
           score += 1
           scoreLabel?.text = "Score: \(score)"
       }
       
       if contact.bodyA.categoryBitMask == dynamiteCategory {
           contact.bodyA.node?.removeFromParent()
           gameOver()
       }
    
       if contact.bodyB.categoryBitMask == dynamiteCategory {
           contact.bodyB.node?.removeFromParent()
           gameOver()
        }
    }
    
    func gameOver () {
        scene?.isPaused = true
        
        gameTimer?.invalidate()
        dynamiteTimer?.invalidate()
        
        yourScoreLabel = SKLabelNode(text: "Your Score:")
        yourScoreLabel?.position = CGPoint(x: 0, y: 200)
        yourScoreLabel?.fontSize = 100
        yourScoreLabel?.zPosition = 1
        if yourScoreLabel != nil {
            addChild(yourScoreLabel!)
        }
        
        finalScoreLabel = SKLabelNode(text: "\(score)")
        finalScoreLabel?.position = CGPoint(x: 0, y: 0)
        finalScoreLabel?.fontSize = 200
        finalScoreLabel?.zPosition = 1
        if yourScoreLabel != nil {
            addChild(finalScoreLabel!)
        }
        
        let playButton = SKSpriteNode(imageNamed: "play")
        playButton.position = CGPoint(x: 0, y: -200)
        playButton.name = "play"
        playButton.zPosition = 1
        addChild(playButton)
    }
}
