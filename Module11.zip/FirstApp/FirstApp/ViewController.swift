//
//  ViewController.swift
//  FirstApp
//
//  Created by user150240 on 3/27/19.
//  Copyright © 2019 Edwin. All rights reserved.
//

import UIKit



class ViewController: UIViewController {

    //captures First name field
    @IBOutlet weak var Text: UITextField!
    
    //captures email address field
    @IBOutlet weak var Text2: UITextField!
    
    //displays captured info on screen after submit button
    @IBOutlet weak var Label: UILabel!
    
    //submit buton action
    @IBAction func Submit(_ sender: Any) {
          if let name = Text.text {
            if let name2 = Text2.text {
                Label.text = "Thank you for signing up! \n \n " + name + "\n" + name2
        }
      }
     
     //Hides keyboard after Submmit button is pressed
     Text2.resignFirstResponder()
     
    //Clears input text fields after submit button
     self.Text.text = ""
     self.Text2.text = ""
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()
    print("Module 11 App Launch Success!")
    }
}

