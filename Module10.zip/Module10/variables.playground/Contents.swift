import UIKit

var str = "Hello, playground"
var amFabulous = false
var scoreATD = true
var scoreAFG = false

scoreATD = !scoreATD
var feelExcitedAboutSpring = true
feelExcitedAboutSpring = amFabulous ? true : false

var checkingAccBal = 2
var dunkindonutsCashier = checkingAccBal >= 5 ? "You just purchased coffee & a donut" : "Sorry, you cant afford it!"
