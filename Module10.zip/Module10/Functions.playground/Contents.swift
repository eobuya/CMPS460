import UIKit

//comments

/*
 comments
*/

var deckLength = 240
var deckWidth = 120
var area = deckLength * deckWidth

//function
func calculateArea(length: Int, width: Int) -> Int {
    return length * width
}

func sayHello() -> String {
    return "Hello Students"
}

//Call functions
print(sayHello())
print(calculateArea(length: deckLength, width: deckWidth))

func greet(person: String) -> String {
    let greeting = "Hello,  " + person + "!"
    return greeting
}
print(greet(person: "Edwin"))

var bankAccBal = 300.99
var itemPurchased = 599.97

func purchasedItem(currentBal: inout Double, itemPrice: Double) {
    if itemPrice <= currentBal{
        currentBal = currentBal - itemPrice
        print("Purchased iitem for: $\(itemPrice)")
    } else {
        print("Sorry not enough")
    }
}
//call the function
purchasedItem(currentBal: &bankAccBal, itemPrice: itemPurchased)
