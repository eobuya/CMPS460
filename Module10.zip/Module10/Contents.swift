import UIKit

var pitScore = 44
var wvuScore = 45

var totalScore = pitScore + wvuScore

var myMoney: Double = 12345678900000000000

var newMoney: Float = 3.79
var remainder = 14 % 5

var randomNumber = 12
if randomNumber % 2 == 0 {
    print("It is an even number")
} else {
    print("It is an odd number")
}
