import UIKit

var firstName = "Edwin"
var lastName = "Obuya"
var suffix = " III"

var fullName = firstName + " " + lastName
fullName.append(suffix)

var tvShow = "game of thrones"
tvShow = tvShow.capitalized

var movie = "I AM NUMBER FOUR"
movie = movie.lowercased()

var statement = "Learning Xcode for the first time."
if statement.contains("Xcode") || statement.contains("the") {
    print("Great, words found")
} else {
    print("Sorry")
}

//replace values in variable statement
statement.replacingOccurrences(of: "for", with: "at")
