import UIKit

var bigben = 23200000.00    //0
var crosby = 87000000.00    //1
var juju = 1144302.00       //2
var mariska = 1080000.00    //3
var jconnor = 844572.00     //4

var salaries: [Double] = [bigben,crosby, juju, mariska,jconnor]

//The size of the array
salaries.count

//Remove an elemnet from the array
salaries.remove(at: 1)
salaries.count

//Create new array
var nbaPlayers = [String]()
print(nbaPlayers.count)
nbaPlayers.append("Lebron James")
nbaPlayers.append("Charles Barkley")
nbaPlayers.append("Michael Jordan")
nbaPlayers.append("Magic")
print(nbaPlayers.count)
nbaPlayers.remove(at: 2)
print(nbaPlayers.count)
nbaPlayers.sort() //alpha sorting by lastname
